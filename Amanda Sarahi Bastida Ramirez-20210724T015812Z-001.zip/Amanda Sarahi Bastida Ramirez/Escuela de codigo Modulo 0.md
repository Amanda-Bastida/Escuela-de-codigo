# # Escuela de codigo Modulo 0
 **Esta carpeta contiene tres carpetas más que contienen la evidencia de las actividades que se desarrollaron a lo largo del modulo 0 :**

---
✨ Carpeta actividad   1
    El contenido de esta carpeta es la resolución de las actividades que se presentaban en los anexos, tambien contiene dos archivos de texto uno sobre la investigación de **Linux y sus distribuciones** y otros donde se explica sobre **los permisos de lectura, escritura y ejecución de los archivos y carpetas.**
---
✨Carpeta actividad 2
Esta carpeta contiene los cuatro certificados del mundo de Interland y las captura de pantalla del historial y los marcadores de una navegador web.

---
✨ Carpeta actividad 3
La última carpeta contiene una captura de pantalla de la terminal despúes de ejecutar los comandos vistos en clase y un archivo .txt donde se explica **Git y la relación que tiene con Github.**

---

* Lo aprendido en el módulo:
Durante este módulo aprendí mas cosas sobre los comandos básicos de Linux, sus distribuciones y lo que ellas significan, sobre git y github ademas de que empecé a familiarizarme más con ellos. Tambien aprendi a realizar archivos readme.md en Dillinger ya que esto último nunca lo habia realizado.
